//
//  ContentView.swift
//  LetsNote
//
//  Created by Swati Rout on 12/07/23.
//

import SwiftUI
import SwiftData

@Model
class ToDoItem {
    var itemText: String
    
    init(itemText: String) {
        self.itemText = itemText
    }
}



struct ContentView: View {
    @Environment(\.modelContext) private var context
    @Query(sort: \ToDoItem.itemText, order: .forward, animation: .smooth) private var allnewItems: [ToDoItem]
    @State private var itemToBeNoted:String = ""
    @Environment(\.modelContext) private var modelContext
    
    var body: some View {
        VStack {
            TextField("Take a Note!", text: $itemToBeNoted)
                .textFieldStyle(.roundedBorder)
            Button(action: {
                //Inserting Item in SwiftData
                let item =  ToDoItem(itemText: itemToBeNoted)
                context.insert(item)
                do {
                    try context.save()
                }catch {
                    print(error.localizedDescription)
                }
            }) {
                Text("Save!")
                    .foregroundColor(.white)
                    .padding()
            }
            .background(Color.gray)
            .cornerRadius(8)
            
            NoteList(newItems: allnewItems)
            
        }.navigationTitle("Taking Some notes before I forget!")
            .padding()
    }
    
    
    
    
    #Preview {
        ContentView()
        
    }
}
