//
//  NoteList.swift
//  LetsNote
//
//  Created by Swati Rout on 12/07/23.
//

import Foundation
import SwiftUI
struct NoteList: View {
    @Environment(\.modelContext) private var context
    let  newItems: [ToDoItem]
    
    //Deleting ListVIew Items by swiping to left
    private func deleteUnwatedNotes(_ indexSet: IndexSet) {
        indexSet.forEach { ind in
            let consideringItem  = newItems[ind]
            context.delete(consideringItem)
            try? context.save()
            
        }
    }
    var body: some View {
        List {
            ForEach(newItems) {
                i in
                Text(i.itemText)
                
            }.onDelete(perform: deleteUnwatedNotes)
        }
    }
}
